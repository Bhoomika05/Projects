

import glob
import configuration
import albumentations
import cv2
import numpy as np
import torch

from util_helpers import label_colors_list, get_label_mask
from util_helpers import ALL_CLASSES, visualize_from_path
from util_helpers import visualize_from_dataloader
from torch.utils.data import Dataset, DataLoader
from PIL import Image

train_data_images = glob.glob(f"{configuration.ROOT_PATH}/train/*")
train_data_images.sort()
train_segmented_images= glob.glob(f"{configuration.ROOT_PATH}/train_mask/*")
train_segmented_images.sort()
valid_images = glob.glob(f"{configuration.ROOT_PATH}/val/*")
valid_images.sort()
valid_segs = glob.glob(f"{configuration.ROOT_PATH}/val_mask/*")
valid_images.sort()

if configuration.DEBUG:
    visualize_from_path(train_data_images, train_segmented_images)

class CamVidDataset(Dataset):
    CLASSES = ALL_CLASSES

    def __init__(self, path_images, path_segs, image_transform, mask_transform, label_colors_list, classes):
        print(f"TRAINING ON CLASSES: {classes}")

        self.path_images = path_images
        self.path_segs = path_segs
        self.label_colors_list = label_colors_list
        self.image_transform = image_transform
        self.mask_transform = mask_transform
        self.class_values = [self.CLASSES.index(cls.lower()) for cls in classes]
        
    def __len__(self):
        return len(self.path_images)
        
    def __getitem__(self, index):
        image = np.array(Image.open(self.path_images[index]).convert('RGB'))
        mask = np.array(Image.open(self.path_segs[index]).convert('RGB'))
          
        
        image = self.image_transform(image=image)['image']
        mask = self.mask_transform(image=mask)['image']
        
        mask = get_label_mask(mask, self.class_values)
       
        image = np.transpose(image, (2, 0, 1))
        
        image = torch.tensor(image, dtype=torch.float)
        mask = torch.tensor(mask, dtype=torch.long) 

        return image, mask

train_image_transform = albumentations.Compose([
    albumentations.Resize(224, 224, always_apply=True),
    albumentations.Normalize(
            mean=[0.45734706, 0.43338275, 0.40058118],
            std=[0.23965294, 0.23532275, 0.2398498],
            always_apply=True)
])
valid_image_transform = albumentations.Compose([
    albumentations.Resize(224, 224, always_apply=True),
    albumentations.Normalize(
            mean=[0.45734706, 0.43338275, 0.40058118],
            std=[0.23965294, 0.23532275, 0.2398498],
            always_apply=True)
])
train_mask_transform = albumentations.Compose([
    albumentations.Resize(224, 224, always_apply=True),
])
valid_mask_transform = albumentations.Compose([
    albumentations.Resize(224, 224, always_apply=True),
])
        
train_dataset = CamVidDataset(train_data_images, train_segmented_images, train_image_transform, 
                              train_mask_transform,
                              label_colors_list, 
                              classes=configuration.CLASSES_TO_TRAIN)
valid_dataset = CamVidDataset(valid_images, valid_segs, valid_image_transform,
                              valid_mask_transform,
                              label_colors_list, 
                              classes=configuration.CLASSES_TO_TRAIN)

train_data_loader = DataLoader(train_dataset, batch_size=configuration.BATCH_SIZE)
valid_data_loader = DataLoader(valid_dataset, batch_size=configuration.BATCH_SIZE)

if configuration.DEBUG:
    visualize_from_dataloader(train_data_loader)
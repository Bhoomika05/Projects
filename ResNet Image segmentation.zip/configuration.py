EPOCHS = 20
SAVE_EVERY = 5 
LOG_EVERY = 5 
BATCH_SIZE = 50
DEVICE = 'cpu'
LR = 0.0001
ROOT_PATH = '/Users/sriram/Documents/Programs/CAP5415/final_project/data'

CLASSES_TO_TRAIN = [
        'background', 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 
    'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike', 
    'person', 'potted plant', 'sheep', 'sofa', 'tv/monitor'
        ]

DEBUG = False
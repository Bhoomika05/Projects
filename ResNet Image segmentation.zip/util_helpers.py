import numpy as np
import matplotlib.pyplot as plt
import torch
import cv2
import configuration

from tensorboardX import SummaryWriter

label_colors_list = [
    (0, 0, 0), 
    (128, 0, 0), 
    (0, 128, 0), 
    (128, 128, 0), 
    (0, 0, 128), 
    (128, 0, 128), 
    (0, 128, 128), 
    (128, 128, 128), 
    (64, 0, 0), 
    (192, 0, 0), 
    (64, 128, 0), 
    (192, 128, 0), 
    (64, 0, 128), 
    (192, 0, 128), 
    (64, 128, 128), 
    (192, 128, 128), 
    (0, 64, 0), 
    (128, 64, 0), 
    (0, 192, 0), 
    (128, 192, 0), 
    (0, 64, 128)
]


ALL_CLASSES = ['background', 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 
    'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike', 
    'person', 'potted plant', 'sheep', 'sofa', 'tv/monitor'
]


class_values = [ALL_CLASSES.index(cls.lower()) for cls in configuration.CLASSES_TO_TRAIN]

class TensorboardWriter():
    def __init__(self):
        super(TensorboardWriter, self).__init__()
        self.writer = SummaryWriter()
    def tensorboard_writer(self, loss, mIoU, pix_acc, iterations, phase=None):
        if phase == 'train':
            self.writer.add_scalar('Train Loss', loss, iterations)
            self.writer.add_scalar('Train mIoU', mIoU, iterations)
            self.writer.add_scalar('Train Pixel Acc', pix_acc, iterations)
        if phase == 'valid':
            self.writer.add_scalar('Valid Loss', loss, iterations)
            self.writer.add_scalar('Valid mIoU', mIoU, iterations)
            self.writer.add_scalar('Valid Pixel Acc', pix_acc, iterations)

def get_label_mask(mask, class_values): 
    
    label_mask = np.zeros((mask.shape[0], mask.shape[1]), dtype=np.uint8)
    for value in class_values:
        for ii, label in enumerate(label_colors_list):
            if value == label_colors_list.index(label):
                label = np.array(label)
                label_mask[np.where(np.all(mask == label, axis=-1))[:2]] = ii
    label_mask = label_mask.astype(int)
    return label_mask


def draw_seg_maps(data, output, epoch, i):
    
    alpha = 0.6 
    beta = 1 - alpha 
    gamma = 0 

    seg_map = output[0] 
    seg_map = torch.argmax(seg_map.squeeze(), dim=0).detach().cpu().numpy()

    image = data[0]
    image = np.array(image.cpu())
    image = np.transpose(image, (1, 2, 0))
    mean = np.array([0.45734706, 0.43338275, 0.40058118])
    std = np.array([0.23965294, 0.23532275, 0.2398498])
    image = std * image + mean
    image = np.array(image, dtype=np.float32)
    image = image * 255 


    red_map = np.zeros_like(seg_map).astype(np.uint8)
    green_map = np.zeros_like(seg_map).astype(np.uint8)
    blue_map = np.zeros_like(seg_map).astype(np.uint8)
    
    for label_num in range(0, len(label_colors_list)):
        if label_num in class_values:
            idx = seg_map == label_num
            red_map[idx] = np.array(label_colors_list)[label_num, 0]
            green_map[idx] = np.array(label_colors_list)[label_num, 1]
            blue_map[idx] = np.array(label_colors_list)[label_num, 2]
        
    rgb = np.stack([red_map, green_map, blue_map], axis=2)
    rgb = np.array(rgb, dtype=np.float32)
    rgb = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    cv2.addWeighted(rgb, alpha, image, beta, gamma, image)
    cv2.imwrite(f"train_seg_maps/e{epoch}_b{i}.jpg", image)

def draw_test_segmentation_map(outputs):
    
    labels = torch.argmax(outputs.squeeze(), dim=0).detach().cpu().numpy()
    red_map = np.zeros_like(labels).astype(np.uint8)
    green_map = np.zeros_like(labels).astype(np.uint8)
    blue_map = np.zeros_like(labels).astype(np.uint8)
    
    for label_num in range(0, len(label_colors_list)):
        if label_num in class_values:
            idx = labels == label_num
            red_map[idx] = np.array(label_colors_list)[label_num, 0]
            green_map[idx] = np.array(label_colors_list)[label_num, 1]
            blue_map[idx] = np.array(label_colors_list)[label_num, 2]
        
    segmented_image = np.stack([red_map, green_map, blue_map], axis=2)
    return segmented_image

def image_overlay(image, segmented_image):
    
    alpha = 0.6 
    beta = 1 - alpha
    gamma = 0
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    segmented_image = cv2.cvtColor(segmented_image, cv2.COLOR_RGB2BGR)
    cv2.addWeighted(segmented_image, alpha, image, beta, gamma, image)
    return image

def visualize_from_dataloader(data_loader): 
   
    data = iter(data_loader)   
    images, labels = data.next()
    image = images[1]
    image = np.array(image)
    image = np.transpose(image, (1, 2, 0))
    mean = np.array([0.45734706, 0.43338275, 0.40058118])
    std = np.array([0.23965294, 0.23532275, 0.2398498])
    image = std * image + mean
    image = np.array(image, dtype=np.float32)
    label = labels[1]
    images = [image, label.squeeze()]
    for i, image in enumerate(images):
        plt.subplot(1, 2, i+1)
        plt.imshow(image)
    plt.show()

def visualize_from_path(image_path, seg_path):
    
    train_sample_img = cv2.imread(image_path[0])
    train_sample_img = cv2.cvtColor(train_sample_img, cv2.COLOR_BGR2RGB)
    train_sample_seg = cv2.imread(seg_path[0])
    train_sample_seg = cv2.cvtColor(train_sample_seg, cv2.COLOR_BGR2RGB)
    images = [train_sample_img, train_sample_seg]
    for i, image in enumerate(images):
        plt.subplot(1, 2, i+1)
        plt.imshow(image)
    plt.show()

def save_model_dict(model, epoch, optimizer, 
                    criterion, valid_iters, train_iters):
    torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': criterion,
            'valid_iters': valid_iters, 
            'train_iters': train_iters, 
            }, f"checkpoints/model_{epoch}.pth")
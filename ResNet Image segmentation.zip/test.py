import torch
import numpy as np
import cv2
import argparse
import configuration
import albumentations

from PIL import Image
from resnet_model import model
from util_helpers import draw_test_segmentation_map, image_overlay

parser = argparse.ArgumentParser()
parser.add_argument('-m', '--model-path', dest='model_path', required=True,
                    help='path to the trained model weights')
parser.add_argument('-i', '--input', required=True, 
                    help='path to input image')
args = vars(parser.parse_args())

transform = albumentations.Compose([
    albumentations.Normalize(
            mean=[0.45734706, 0.43338275, 0.40058118],
            std=[0.23965294, 0.23532275, 0.2398498],
            always_apply=True)
])

model = model

checkpoint = torch.load(args['model_path'])

model.load_state_dict(checkpoint['model_state_dict'])

model.eval().to(configuration.DEVICE)

image = np.array(Image.open(args['input']).convert('RGB'))
orig_image = image.copy()

image = transform(image=image)['image']
image = np.transpose(image, (2, 0, 1))
image = torch.tensor(image, dtype=torch.float)

image = image.unsqueeze(0).to(configuration.DEVICE)

outputs = model(image)
outputs = outputs['out']
segmented_image = draw_test_segmentation_map(outputs)
result = image_overlay(orig_image, segmented_image)

cv2.imshow('Result', result)
cv2.waitKey(0)
save_name = f"{args['input'].split('/')[-1].split('.')[0]}"
cv2.imwrite(f"outputs/{save_name}.jpg", result)